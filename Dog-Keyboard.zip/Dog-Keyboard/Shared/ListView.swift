//
//  ListView.swift
//  Xcode13DK (iOS)
//
//  Created by Johnny Archard on 11/9/22.
//

import SwiftUI

struct ListView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        ListView()
    }
}
